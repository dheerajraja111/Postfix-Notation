var app=angular.module('Assignment', []);

app.controller('PolishController', function($scope){
	$scope.polishNotation = function(expression){    //polishNotation function calculates the postfix expression
		var resultArray = [];		//output array
		var polishExp = $scope.expression.split(" ");
		
		var i;
		var len = polishExp.length;
		$scope.showError = false;
		var errorMessage ="";   //Error message
		
		for(i=0;i<len;i++){
			if(!isNaN(polishExp[i])){
				resultArray.push(polishExp[i]);
			}
			else{
				var a = resultArray.pop();
				var b = resultArray.pop();
				var operator = polishExp[i];
				switch(operator){
					case "+": 
						resultArray.push(parseInt(a) + parseInt(b));
						break;
					case "-":
						resultArray.push(parseInt(a) - parseInt(b));
						break;
					case "*":
						resultArray.push(parseInt(a) * parseInt(b));
						break;
					case "/":
						resultArray.push(parseInt(a) / parseInt(b));
						break;
					case "^":
						resultArray.push(Math.pow(parseInt(b), parseInt(a)));
						break;					
				}
			}			
		}
		if(resultArray.length > 1 || resultArray.length <=0 || isNaN(resultArray[0])) {
			$scope.showError = true;
			$scope.errorMessage = "Input format is invalid";
			$scope.output = "";
		} 
		else if (resultArray[0] == 'Infinity' || resultArray[0] == null){
			$scope.output = "";
			$scope.showError = true;
			$scope.errorMessage = "Input format is invalid";
		} else {
			$scope.output=resultArray.pop();			
		}
		return $scope.output;
	}
});



